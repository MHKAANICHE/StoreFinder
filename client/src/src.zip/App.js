import React from "react";
import {Routes, Route} from 'react-router-dom';
import Home from "./views/Home";
import Details from "./views/Details";
import Update from "./views/Update";
function App () {


    return(
        <div>
            <Routes>
                <Route path = "/" element= {<Home/>} />
                <Route path="/product/:id_Prod"  element={<Details/>}/>
                <Route path="/update/:id_Prod" element={<Update/>}/>
            </Routes>
        </div>
    )
}

export default App