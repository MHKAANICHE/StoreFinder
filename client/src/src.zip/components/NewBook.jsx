import axios from 'axios'
import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import { useNavigate } from 'react-router-dom';


const NewBook = () => {

    const [author, setAuthor]= useState("")

    const navigate = useNavigate();
    
    const cancelHandle = (e) => navigate('/') ;

    const submitHandler = (e) => {

        // prevent page rendering 
        e.preventDefault();
    
        // Create the new Obj
        const newBook = {
            title:"ABC",
            pages:"125",
            author
        }
    
        // call Backend to add new Obj
        axios
        .post('http://localhost:8000/api/newBook', newBook)
        .then(res =>{
            console.log("NewBook :",res)
            navigate('/');
        })
        .catch(err=>{
            console.log("NewBook - Error : ",err)
        })
    
    }

    return (
    <div>
        <h1>Favorite authors</h1>
        <Link to={("/")}>Home</Link>
        <h3>Add a new author:</h3>
        <form onSubmit={submitHandler}>
            <fieldset>  
                <label>Name:</label>
                <input type="text" onChange={(e)=> setAuthor(e.target.value)}/>
                <div>
                    <button onClick={cancelHandle}>Cancel</button>
                    <input type="submit"  value="Submit"/>
                </div>
            </fieldset>
        </form>
    </div>
  )
}

export default NewBook