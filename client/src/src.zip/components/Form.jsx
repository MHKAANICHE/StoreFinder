import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Form = ({ onSubmit, productToUpdate, refresh }) => {
  const [title, setTitle] = useState(productToUpdate.title || '');
  const [price, setPrice] = useState(productToUpdate.price || 0);
  const [description, setDescription] = useState(productToUpdate.description || '');

  // Update the state when the productToUpdate prop changes (without it, the form will render empty : asynchronus action)
  useEffect(() => {
    setTitle(productToUpdate.title || '');
    setPrice(productToUpdate.price || 0);
    setDescription(productToUpdate.description || '');
  }, [productToUpdate]);

  //console.log("Form - productToUpdate._id : ", productToUpdate._id)

  const onCreate = (newProduct) => {
    axios
      .post('http://localhost:8000/api/new', newProduct)
      .then((res) => {
        refresh();
        console.log(res.data);
      })
      .catch((err) => {
        console.log('Create New - Error:', err);
      });
  }

  const submitHandler = (e) => {
    e.preventDefault();
    const newProduct = {
      title,
      price,
      description,
    };

    productToUpdate._id ? onSubmit(newProduct) : onCreate(newProduct);
  };

  return (
    <div>
      <h1>{productToUpdate._id ? 'Product Edit' : 'Product Manager'}</h1>
      <form onSubmit={submitHandler}>
        <label>Title</label>
        <input type="text" value={title} onChange={(e) => setTitle(e.target.value)} />
        <br />
        <label>Price</label>
        <input type="text" value={price} onChange={(e) => setPrice(e.target.value)} />
        <br />
        <label>Description</label>
        <input type="text" value={description} onChange={(e) => setDescription(e.target.value)} />
        <br />
        <input type="submit" value={productToUpdate._id ? 'Update' : 'Create'} />
      </form>
    </div>
  );
};

export default Form;
