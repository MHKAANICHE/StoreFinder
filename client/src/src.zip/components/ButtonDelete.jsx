import React from 'react'
import axios from 'axios'

const ButtonDelete = ({refresh, product}) => {

    const handleDelete = (id)=>{
        axios
        .delete(`http://localhost:8000/api/one/${id}`)
        .then(res=>{ 
            refresh()
            console.log(res)})
        .catch(err=> console.log("Delete - Error :",err))
    }

  return (
    <div>
        <button onClick={(e)=>{handleDelete(product._id)}}>  Delete </button>    
    </div>
  )
}

export default ButtonDelete