import axios from 'axios'
import React, { useState, useEffect } from 'react'
import {Link} from 'react-router-dom'
import ButtonDelete from './ButtonDelete'
const Dashboard = (props) => {

    const [allProducts, setAllProducts] = useState([])
    const {refreshState, refresh} = props

    useEffect(()=>{
        axios
        .get("http://localhost:8000/api/findAll")
        .then(res=>{
            // res.status(200).setAllProducts(res.data)
            console.log(res.data)
            setAllProducts(res.data)
        })
        .catch(err=>{
            console.log("Dashboard - Error :",err)
            // err.status(400).json({message :"Dashboard - Error :",err})
        })
    },[refreshState])

    console.log("allProducts :",allProducts)

    

  return (
    <div>
        <h1>All Products :</h1><ul >
        {
            allProducts.map((product)=>{
                return(                          
                            <li key = {product._id}>
                                    <Link to={"/product/"+product._id}> {product.title} </Link> 
                                    <Link to={"/update/"+product._id}> Edit            </Link>
                                    <ButtonDelete  product={product} refresh={refresh}/>
                                    {/* <button onClick={(e)=>{handleDelete(product._id)}}>  Delete </button>                                                          */}
                            </li> 
                )})                          
        } 
     </ul> </div>
  )
}

export default Dashboard