import React from 'react';
import { useParams } from 'react-router-dom';

const StyledText = () => {

const { word, textColor, backgroundColor } = useParams();

  const styles = {
    color: textColor,
    backgroundColor: backgroundColor,
    padding: '10px',
  };

  return <h1 style={styles}>{word}</h1>;
};

export default StyledText