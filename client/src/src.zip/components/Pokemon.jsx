
import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Pokemon = () => {

   const [pokemonList, setpokemonList] = useState([]);
 
  useEffect(()=>{

    const url = `https://pokeapi.co/api/v2/pokemon/`;

    
    axios.get(url)
      .then(response => {
        setpokemonList(response.data.results)
        console.log("setpokemonList : ", response.data.results);
      })
      .catch(error => {
        console.error(error);
      });

  },[])

  console.log("pokemonList : ", pokemonList);

  return(
      <div>
         <fieldset>
        {
          pokemonList.map((pokemon)=>{
            return(
              <div key ={pokemon.url}>
                <h3>{pokemon.name}</h3>
              </div>
            )})
         }
         </fieldset>
      </div>
    )
}

export default Pokemon;