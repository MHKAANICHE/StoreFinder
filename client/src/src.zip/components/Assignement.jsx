import React from 'react'
import { useParams } from 'react-router-dom';

const Assignement = () => {
  
    const {extra} = useParams();


  return (
    <div>
        {
            isNaN(extra)
            ? <div> The world is : {extra} </div>
            : <div> The number is : {extra}</div>

        }
    </div>
  )
}

export default Assignement
