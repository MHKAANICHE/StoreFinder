import axios from 'axios';
import React, { useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'

const UpdateBook = () => {

    const [author, setAuthor] = useState("")

    const {book_id} = useParams()
    console.log("book_id", book_id)

    const navigate = useNavigate();
    const cancelHandle = (e)=> navigate('/');

    const submitHandler = (e) => {
        
        e.preventDefault();

        const updatedBook = {
            title:"ABC",
            pages:"125",
            author
        }
        console.log("updatedBook",updatedBook)
        console.log(`http://localhost:8000/api/book/${book_id}`)
        axios
        .put( `http://localhost:8000/api/book/${book_id}`,updatedBook)
        .then(res=>{
            console.log("Update Book : ",res.data)
        })
        .catch(err=> {
            console.log("Update Book - Error :",err.data)
        })

    }


  return (
    <div>
        <h1>Favorite authors</h1>
        <Link to={("/")}>Home</Link>

        <h3>Edit this author:</h3>
        <form onSubmit={submitHandler}>
            <label>Name:</label>
            <input type="text" onChange={(e)=> setAuthor(e.target.value)} />
            <div>
                <button onClick={cancelHandle}>Cancel</button>
                <button type="submit">Submit</button>
            </div>
        </form>
    </div>
  )
}

export default UpdateBook