import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import axios from 'axios';
import Form from '../components/Form';

const Update = () => {
  const { id_Prod } = useParams();
  const navigate = useNavigate();
  const [product, setProduct] = useState({});

  useEffect(() => {
    axios
      .get(`http://localhost:8000/api/one/${id_Prod}`)
      .then((res) => {
        setProduct(res.data);
      })
      .catch((err) => console.log('Get info - Error:', err));
  }, [id_Prod]);
  console.log("Update - UseEffect - product : ",product)

  const updateHandler = (updatedProduct) => {
    axios
      .put(`http://localhost:8000/api/one/${id_Prod}`, updatedProduct)
      .then((res) => {
        console.log("Update - updateHandler - res.data : ",res.data)
        navigate('/');
      })
      .catch((err) => {
        console.log('Update - Error:', err);
      });
  };

  return (
    <div>
      {/* Render the Form component with the product data for updating */}
      { product ? 
        <Form onSubmit={updateHandler} productToUpdate={product} refresh={null} />
        : null
      }
    </div>
  );
};

export default Update;
