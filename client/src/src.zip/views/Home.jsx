import React, { useState } from 'react';
import axios from 'axios';
import Form from '../components/Form';
import Dashboard from '../components/Dashboard';

const Home = () => {
  const [refreshState, setRefreshState] = useState(false);

  const refresh = () => {
    setRefreshState(!refreshState);
  };

  return (
    <div>
      {/* Render the Form component with the refresh callback for updating the list */}
      <Form onSubmit={null} productToUpdate={{}} refresh={refresh} />
      <Dashboard refreshState={refreshState} refresh= {refresh}/>
    </div>
  );
};

export default Home;
