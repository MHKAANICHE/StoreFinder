import axios from 'axios'
import React,{useEffect, useState} from 'react'
import { useParams } from 'react-router-dom'

const Details = () => {

    const [product, setProduct]= useState({})
    const {id_Prod} = useParams()

    useEffect(()=>{
        axios
        .get(`http://localhost:8000/api/one/${id_Prod}`)
        .then(res=> {
            console.log(res.data)
            setProduct(res.data.product)
        })
        .catch(err=>{
            console.log("Details- Error: ",err)
        })
    },[])
    // console.log("product : ",product)
    // console.log("product.title : ",product.title)

  return (
    <div>
        <h1>Product Details:</h1>
        <h3>Title : {product.title}</h3>
        <h3>Price : {product.price}</h3>
        <h3>Description : {product.description}</h3>

    </div>
  )
}

export default Details